var __create = Object.create;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __getProtoOf = Object.getPrototypeOf;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toESM = (mod, isNodeMode, target) => (target = mod != null ? __create(__getProtoOf(mod)) : {}, __copyProps(
  // If the importer is in node compatibility mode or this is not an ESM
  // file that has been converted to a CommonJS file using a Babel-
  // compatible transform (i.e. "__esModule" has not been set), then set
  // "default" to the CommonJS "module.exports" for node compatibility.
  isNodeMode || !mod || !mod.__esModule ? __defProp(target, "default", { value: mod, enumerable: true }) : target,
  mod
));
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);

// netlify/functions/flow-create-payment.js
var flow_create_payment_exports = {};
__export(flow_create_payment_exports, {
  handler: () => handler
});
module.exports = __toCommonJS(flow_create_payment_exports);
var import_crypto = __toESM(require("crypto"), 1);
var FLOW_API_URL = process.env.FLOW_ENV === "sandbox" ? "https://sandbox.flow.cl/api" : "https://www.flow.cl/api";
var API_KEY = process.env.FLOW_API_KEY;
var SECRET_KEY = process.env.FLOW_SECRET_KEY;
function signParams(params) {
  const keys = Object.keys(params).sort();
  const toSign = keys.map((k) => `${k}${params[k]}`).join("");
  return import_crypto.default.createHmac("sha256", SECRET_KEY).update(toSign).digest("hex");
}
var handler = async (event) => {
  if (event.httpMethod !== "POST") {
    return { statusCode: 405, body: "Method not allowed" };
  }
  try {
    const { userId, userEmail } = JSON.parse(event.body);
    if (!userId || !userEmail) {
      return { statusCode: 400, body: JSON.stringify({ error: "Faltan datos" }) };
    }
    const commerceOrder = `PREMIUM-${userId}-${Date.now()}`;
    const baseUrl = process.env.URL || "https://laminax-chile.netlify.app";
    const params = {
      apiKey: API_KEY,
      amount: 2990,
      commerceOrder,
      currency: "CLP",
      email: userEmail,
      paymentMethod: 9,
      subject: "LaminaX Premium - Suscripci\xF3n mensual",
      urlConfirmation: `${baseUrl}/.netlify/functions/flow-confirm-payment`,
      urlReturn: `${baseUrl}/upgrade?status=success`,
      optional: JSON.stringify({ userId })
    };
    params.s = signParams(params);
    const formBody = Object.keys(params).map((k) => `${encodeURIComponent(k)}=${encodeURIComponent(params[k])}`).join("&");
    const response = await fetch(`${FLOW_API_URL}/payment/create`, {
      method: "POST",
      headers: { "Content-Type": "application/x-www-form-urlencoded" },
      body: formBody
    });
    const data = await response.json();
    if (data.url && data.token) {
      return {
        statusCode: 200,
        body: JSON.stringify({
          paymentUrl: `${data.url}?token=${data.token}`,
          token: data.token,
          commerceOrder
        })
      };
    } else {
      console.error("Flow error:", data);
      return {
        statusCode: 400,
        body: JSON.stringify({ error: data.message || "Error al crear pago en Flow" })
      };
    }
  } catch (err) {
    console.error("Function error:", err);
    return {
      statusCode: 500,
      body: JSON.stringify({ error: "Error interno del servidor" })
    };
  }
};
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  handler
});
